import Carousel from "./components/Carousel";
import InputForm from "./components/InputFrom";

function App() {
  return (
    <div>
    <Carousel/>
    <InputForm/>
    
    </div>
  );
}

export default App;
